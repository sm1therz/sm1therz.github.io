Note: two of the notebooks in this folder are locally saved copies of famous Google Colab notebooks, and will only run on a computer with an NVidia GPU. 
- DreamBooth_Stable_Diffusion.ipynb
- stable_diffusion.ipynb
It is recommended to use these notebooks for reference only.